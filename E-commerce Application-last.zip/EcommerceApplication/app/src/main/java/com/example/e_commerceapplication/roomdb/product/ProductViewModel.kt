package com.example.e_commerceapplication.roomdb.product

import androidx.lifecycle.*
import com.example.e_commerceapplication.roomdb.UserEntity
import kotlinx.coroutines.launch

class ProductViewModel(private val productRepo: ProductRepo) : ViewModel() {

    fun allProducts(productEntity: ProductEntity) = productRepo.allProduct(productEntity).asLiveData()
//    val allProducts: LiveData<List<ProductEntity>> = productRepo.allProduct().asLiveData()

    fun allWishList(productEntity: ProductEntity) = productRepo.allWishList((productEntity)).asLiveData()

    fun getProductSave(productEntity: ProductEntity) = productRepo.getProductSave(productEntity)

    fun insertProduct(productEntity: ProductEntity) = viewModelScope.launch {
        productRepo.insertProduct(productEntity)
    }

    fun insertList(productEntity: List<ProductEntity>) = viewModelScope.launch {
        productRepo.insertList(productEntity)
    }

    fun updateProduct(productEntity: ProductEntity) = viewModelScope.launch {
        productRepo.updateProduct(productEntity)
    }

    class ProductViewModelFactory(private val repository: ProductRepo): ViewModelProvider.Factory {
        override fun <T : ViewModel?> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(ProductViewModel::class.java)){
                return ProductViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
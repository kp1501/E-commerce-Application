package com.example.e_commerceapplication.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.e_commerceapplication.repository.RegisterRepository
import com.example.e_commerceapplication.roomdb.UserEntity
import kotlinx.coroutines.launch

class LoginViewModel(private val repository: RegisterRepository): ViewModel() {

    fun getUser(entity: UserEntity) = repository.getUser(entity)

    fun getId(entity: UserEntity) = repository.getId(entity)

    class LoginViewModelFactory(private val repo: RegisterRepository) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(LoginViewModel::class.java)) {
                @Suppress("UNCHECKED_CAST")
                return LoginViewModel(repo) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}


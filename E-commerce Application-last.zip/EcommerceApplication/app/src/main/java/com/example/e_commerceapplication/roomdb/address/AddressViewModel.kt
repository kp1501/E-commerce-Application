package com.example.e_commerceapplication.roomdb.address

import androidx.lifecycle.*
import kotlinx.coroutines.launch

class AddressViewModel(private val addressRepo: AddressRepo): ViewModel() {

    val allAddress: LiveData<List<AddressEntity>> = addressRepo.allAddress.asLiveData()

    fun insertAddress(addressEntity: AddressEntity) = viewModelScope.launch {
        addressRepo.insertAddress(addressEntity)
    }

    fun deleteAddress(addressEntity: AddressEntity) = viewModelScope.launch {
       addressRepo.deleteAddress(addressEntity)
    }

    class AddressViewModelFactory(private val repo: AddressRepo): ViewModelProvider.Factory {
        override fun <T : ViewModel?> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(AddressViewModel::class.java)){
                return AddressViewModel(repo) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
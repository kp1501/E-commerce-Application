package com.example.e_commerceapplication.roomdb

import android.content.Context
import androidx.room.CoroutinesRoom
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.e_commerceapplication.R
import com.example.e_commerceapplication.roomdb.address.AddressDao
import com.example.e_commerceapplication.roomdb.address.AddressEntity
import com.example.e_commerceapplication.roomdb.cart.CartDao
import com.example.e_commerceapplication.roomdb.cart.CartEntity
import com.example.e_commerceapplication.roomdb.product.ProductDao
import com.example.e_commerceapplication.roomdb.product.ProductEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

@Database(entities = [UserEntity::class, ProductEntity::class, CartEntity::class, AddressEntity::class], version = 1, exportSchema = false)
abstract class Database : RoomDatabase() {

    abstract fun registerDatabaseDao(): UserDao
    abstract fun registerData(): ProductDao
    abstract fun registerDataCart(): CartDao
    abstract fun registerDataAddress(): AddressDao

    companion object {

        @Volatile
        private var INSTANCE : com.example.e_commerceapplication.roomdb.Database? = null

        fun getInstance(context: Context, scope: CoroutineScope): com.example.e_commerceapplication.roomdb.Database {
            return INSTANCE ?: synchronized(com.example.e_commerceapplication.roomdb.Database::class.java) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    com.example.e_commerceapplication.roomdb.Database::class.java,
                    "user_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                // return instance
                instance
            }
        }

//        private class DatabaseCallback(
//            private val scope: CoroutineScope
//        ) : RoomDatabase.Callback() {
//
//            override fun onCreate(db: SupportSQLiteDatabase) {
//                super.onCreate(db)
//                INSTANCE?.let { database ->
//                    scope.launch {
//                        populateDatabase(database.registerData())
//                    }
//                }
//            }
//
//            suspend fun populateDatabase(productDao: ProductDao) {
//
//                // Add sample words.
//                var product = ProductEntity(0, R.drawable.shoe.toString(),"Shoes","1100 Rs","Shoes for men","shoes",0,0)
//                productDao.insertProduct(product)
//
//                product = ProductEntity(0,R.drawable.shoes.toString(),"Shoes","1600 Rs","Shoes for men","shoes",0,0)
//                productDao.insertProduct(product)
//
//                product = ProductEntity(0,R.drawable.shirt.toString(),"Shirt","1300 Rs","Shirt for men","shirt",0,0)
//                productDao.insertProduct(product)
//
//                product = ProductEntity(0,R.drawable.tech.toString(),"Tech","1200 Rs","Tech for men","tech",0,0)
//                productDao.insertProduct(product)
//
//                product = ProductEntity(0,R.drawable.tshirt.toString(),"T-shirt","1900 Rs","T-shirt for men","t-shirt",0,0)
//                productDao.insertProduct(product)
//            }
//        }
    }
}
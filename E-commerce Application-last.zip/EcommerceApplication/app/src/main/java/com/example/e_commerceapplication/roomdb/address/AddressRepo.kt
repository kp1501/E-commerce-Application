package com.example.e_commerceapplication.roomdb.address

import androidx.annotation.WorkerThread
import kotlinx.coroutines.flow.Flow

class AddressRepo(private val addressDao: AddressDao) {

    val allAddress: Flow<List<AddressEntity>> = addressDao.fetchAddressList()

    @WorkerThread
    suspend fun insertAddress(addressEntity: AddressEntity) {
        addressDao.insertAddress(addressEntity)
    }

    @WorkerThread
    suspend fun deleteAddress(addressEntity: AddressEntity) {
        addressDao.deleteAddress(addressEntity)
    }
}
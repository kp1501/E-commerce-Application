package com.example.e_commerceapplication

import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.graphics.drawable.BitmapDrawable
import java.io.ByteArrayOutputStream


class ImageConverter(drawable: Drawable?) {

    var bitmap = (drawable as BitmapDrawable).bitmap
    var stream = ByteArrayOutputStream()
    val bi = bitmap.compress(Bitmap.CompressFormat.WEBP,25,stream)
    var byteArray = stream.toByteArray()

}
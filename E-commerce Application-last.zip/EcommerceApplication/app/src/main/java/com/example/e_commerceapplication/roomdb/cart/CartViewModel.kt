package com.example.e_commerceapplication.roomdb.cart

import androidx.lifecycle.*
import kotlinx.coroutines.launch

class CartViewModel(private val cartRepo: CartRepo) : ViewModel() {

    fun allProducts(cartEntity: CartEntity) = cartRepo.allProduct(cartEntity).asLiveData()

    fun insertProduct(cartEntity: CartEntity) = viewModelScope.launch {
        cartRepo.insertCart(cartEntity)
    }

    fun deleteCart(cartEntity: CartEntity) = viewModelScope.launch {
        cartRepo.deleteCart(cartEntity)
    }

    fun updateCart(cartEntity: CartEntity) = viewModelScope.launch {
        cartRepo.updateCart(cartEntity)
    }

    class CartViewModelFactory(private val repo: CartRepo): ViewModelProvider.Factory {
        override fun <T : ViewModel?> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(CartViewModel::class.java)){
                return CartViewModel(repo) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
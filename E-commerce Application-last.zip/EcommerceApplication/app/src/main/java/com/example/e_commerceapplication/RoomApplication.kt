package com.example.e_commerceapplication

import android.app.Application
import com.example.e_commerceapplication.repository.RegisterRepository
import com.example.e_commerceapplication.roomdb.Database
import com.example.e_commerceapplication.roomdb.address.AddressRepo
import com.example.e_commerceapplication.roomdb.cart.CartRepo
import com.example.e_commerceapplication.roomdb.product.ProductRepo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

class RoomApplication: Application() {
    val applicationScope = CoroutineScope(SupervisorJob())
    // Using by lazy so the database and the repository are only created when they're needed
    // rather than when the application starts
    private val database by lazy { Database.getInstance(this, applicationScope) }
    val repo by lazy { RegisterRepository(database.registerDatabaseDao()) }
    val repository by lazy { ProductRepo(database.registerData()) }
    val repositorycart by lazy { CartRepo(database.registerDataCart()) }
    val repoAddress by lazy { AddressRepo(database.registerDataAddress()) }
}
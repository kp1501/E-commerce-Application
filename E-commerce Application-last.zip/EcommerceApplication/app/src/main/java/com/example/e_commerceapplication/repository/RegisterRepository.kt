package com.example.e_commerceapplication.repository

import com.example.e_commerceapplication.roomdb.UserDao
import com.example.e_commerceapplication.roomdb.UserEntity
import kotlinx.coroutines.flow.Flow

class RegisterRepository(private val dao: UserDao) {

    fun getId(user: UserEntity): Int{
        return dao.getId(user.userEmail)
    }

    suspend fun insert(user : UserEntity){
        dao.insert(user)
    }

    fun getUser(user: UserEntity): UserEntity?{
        return dao.getUser(user.userEmail, user.password)
    }
}
